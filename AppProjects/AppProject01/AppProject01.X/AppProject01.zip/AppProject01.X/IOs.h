#ifndef IOS_H
#define IOS_H

void InitIO();
void checkIO();

void addSeconds(uint8_t s);

#endif