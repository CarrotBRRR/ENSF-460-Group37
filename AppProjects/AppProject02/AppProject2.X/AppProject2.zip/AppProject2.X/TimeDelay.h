#ifndef TIMEDELAY_H
#define TIMEDELAY_H

void delay_ms(uint32_t time);

#endif