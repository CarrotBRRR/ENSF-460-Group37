#ifndef IOS_H
#define IOS_H

void IOinit();

#endif