#ifndef IOS_H
#define IOS_H

void IOinit();
uint8_t IOcheck();

#endif